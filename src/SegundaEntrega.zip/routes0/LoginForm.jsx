import { useState } from 'react'
import InputField from './InputField';


function LoginForm(props) {
   
    const loginHandle = async () => {
      if(!user || !password){

        alert("Favor de ingresar usuario y contraseña")

        return
      }

      const data = {
        email: user,
        contrasena: password
      }

      const res = await fetch('http://localhost:3000/login',{
        method: 'POST',
        headers:{
          'content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      })

      if(res.ok){
        alert("Te has logiado correctamente!!!")

        

      }else{
        alert("Favor de revisar, usuario y contraseña")
      }

    }
   
  const [user, setUser] = useState("")
  const [password, setPassword] = useState("")
   
   return ( 
   <div className="card2">

    <InputField setText={setUser} label="Correo"></InputField>
    <br></br>

    <InputField setText={setPassword} type="Password" label="Contraseña"></InputField>
    <br/>
    <button onClick={loginHandle}>Acceder</button>

  </div>
  )
    
}

export default LoginForm

import { useState } from 'react'
import LoginForm from './routes0/LoginForm'
import RegisterForm from './routes0/RegisterForm'
import './App.css'

function App() {
   
   
  return ( 
    <>
    <div class='card'>
          <h1>Iniciar Sesion</h1>
          <LoginForm></LoginForm>
          <hr></hr>
          <h1>Agregar user</h1>
          <RegisterForm></RegisterForm>

    </div>
    </>
  )
}

export default App
